
# Convert bytes to gigabytes
def bytes_to_gb(size):
    return size / 1024 / 1024 / 1024
